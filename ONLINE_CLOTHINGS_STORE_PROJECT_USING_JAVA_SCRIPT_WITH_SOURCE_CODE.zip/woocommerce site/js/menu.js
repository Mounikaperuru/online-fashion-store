function homehover()
{
document.getElementById("home") 
}
function home(){
document.getElementById("home")
}
function ticketbookinghover(){
document.getElementById("ticketbooking")
}
function ticketbooking(){
document.getElementById("ticketbooking")
}
function snackshover(){
document.getElementById("snacks")
} function snacks(){
document.getElementById("food")
}
function contacthover(){
document.getElementById("contact")
} function contact(){
document.getElementById("contact")
}